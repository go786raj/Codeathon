var config = {
    "ClientId": "ABx7Iw1SsQHwLIK5ItH3oHjGNAguJUKUGmBEwlGdf3NjF5OrEN",
    "ClientSecret": "r2XqejHn88H0yKH8t6HKOi9FLoasqDXWLOUKGzb3",
    "AccessToken": "eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiZGlyIn0..27e3L_kuvBak9gjBhE8HNA.waSHxOD3uaWIAWmW9VaJUX7VxCA9fjt-ggnpksXzlOjGFxHVlq2wPxFUclb0kTL6MG9UtU8BVe9vAr7xdHsiFoh53Ex5w9YmR8zJO4KKK2y5EnJfkk8B4lB07u5tLyB0PCFjzl94rAaHEOLJPO7bM3fo7aaU0Ss-jJHJt79OoUFIbdhj0O4rQp46MGfdUMTtzKF30TKD4bSDuptz-NfvDUqr-Zla4HUdWgCJfiJR4WBflJ5KXAy-yen0euapFefKh7L_VH0sksvbs4BFyvFk4M-GVHlJWWxMupEaAIMxSgVW5Pg8_IdmEP5V5bbiv9JSOZ9NHYfpPwCSf2F5w3yK8SnDiM4ujTloCIClC9TSxqQSFBIui8KXSTQhuvTnd3PRowTHPYWqIkVZt1eF8WCfNByCv5cchN5D-IIiivxhVIs0Zsn6-3owyHRtIPhxIXY_66RcpOiwIOQiu1LXmdkodIpvdez55cKYa7p-K5pP2SHKR129oTUnIf1vs0EAB3WhHzRZFghZPwco6yiMHfg7FzNykWBld_smKQhA6SowT1N9261Lc5WwbTPS2iV2EwNyT2TBUTtbOrC5BDX66uHWniJtY205h24Ro0XRBsR4kTkamSEh3mcphc_O0wlHQqxYjbAZ3zvwq5zbYYfQnKtG0I-9ZnEpxb8Jqmwmw8wKbsUMEdCEGmyscw0ILu0MoiZY_PtpxlLfnj-jutCVOei9fUrMBgKSk3cT_UV9JjA4mBwcT55TYQChhWUg7KunTfbT01PgPccimjvbz6cUzWj_HWf92Ig-Ruwf-YwDP8nVAjoPgWMfMHX4HzA13Vsp4WRNZoc4QbJTbplRvbRhUWnx-wI67DMWDM-auQ0JNHX9ow8.v67qnWh5y7mS9WaCeqUc9w",
    "RefreshToken": "AB11616081954ZWUU7lwnUmdgM6IlKJxvXzpxNnRY8IV2Ap5ua",
    "RealmId": "4620816365149626560",
    "AccountingBaseUrl": "https://sandbox-quickbooks.api.intuit.com",
    "DiscoveryUrl": "https://developer.intuit.com/.well-known/openid_sandbox_configuration/",
    "MinorVersion": "12",
    "environment":"sandbox"
  };
  
  module.exports = config;