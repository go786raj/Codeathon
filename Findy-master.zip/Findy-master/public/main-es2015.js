(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"text-align: center;font-size: 24px;font-family: 'Lato', sans-serif;background: transparent;\">\n    Findy\n</div>\n<router-outlet></router-outlet>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/calender/calender.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/calender/calender.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"col-12\">\n\n    Select a Date:\n\n\n    <br>\n\n    <select name=\"\" id=\"\" class=\"form-control\">\n        <option value=\"Dec 12,2020\">Dec 12,2020</option>\n        <option value=\"Dec 13,2020\">Dec 13,2020</option>\n        <option value=\"Dec 14,2020\">Dec 14,2020</option>\n        <option value=\"Dec 15,2020\">Dec 15,2020</option>\n    </select>\n    <br>\n    <br>\n    <button class=\"btn btn-default\" (click)=\"schedule()\">Schedule the Call</button>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/choose-page/choose-page.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/choose-page/choose-page.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid pt-5\">\n    <div class=\"row\">\n        <div class=\"col-12\" style=\"\">\n            <!-- <section class=\"baby_img mt-5\" (click)=\"select()\">\n            </section> -->\n            <img class=\"baby_img\" src=\"assets/Profilepic/{{selected.name}}.jpg\" alt=\"\" (click)=\"select()\">\n            <br>\n            <div class=\"col-12\" style=\"text-align: center;\">\n                <!-- <div class=\"col-6\" style=\"text-align:left;\"> -->\n                    <h3>{{selected.name}}</h3>\n                <!-- </div> -->\n                <!-- <div class=\"col-6\" style=\"text-align:right;\"> -->\n                    <h4>{{selected['price/hr']}}</h4>\n                <!-- </div> -->\n                    {{selected['experience']}}\n                    <br>\n                    \n            </div>\n        </div>\n    </div>\n     <div class=\"row pt-5\">\n          <div class=\"col-6\">\n            <!-- <img class=\"right-white\" src=\"assets/images/left-white-arrow.svg\" alt=\"\"> -->\n          </div>\n         <div class=\"col-6 text-right\">\n             <img class=\"right-white\" (click)=\"nextChoice()\" src=\"assets/images/right-white-arrow.svg\" alt=\"\">\n         </div>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/components.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/components.component.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<!------ Include the above in your HEAD tag ---------->\n\n\n\n\n\t<div class=\"container h-100\">\n\t\t<div class=\"d-flex justify-content-center h-100\">\n\t\t\t<div class=\"user_card\">\n\t\t\t\t<div class=\"d-flex justify-content-center\">\n\t\t\t\t\t<div class=\"brand_logo_container\">\n\t\t\t\t\t\t<img src=\"https://cdn.freebiesupply.com/logos/large/2x/pinterest-circle-logo-png-transparent.png\" class=\"brand_logo\" alt=\"Logo\">\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"d-flex justify-content-center form_container\">\n\t\t\t\t\t<form>\n\t\t\t\t\t\t<div class=\"input-group mb-3\">\n\t\t\t\t\t\t\t<div class=\"input-group-append\">\n\t\t\t\t\t\t\t\t<span class=\"input-group-text\"><i class=\"fas fa-user\"></i></span>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<input type=\"text\" name=\"\" class=\"form-control input_user\" value=\"\" placeholder=\"username\">\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"input-group mb-2\">\n\t\t\t\t\t\t\t<div class=\"input-group-append\">\n\t\t\t\t\t\t\t\t<span class=\"input-group-text\"><i class=\"fas fa-key\"></i></span>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<input type=\"password\" name=\"\" class=\"form-control input_pass\" value=\"\" placeholder=\"password\">\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox\">\n\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlInline\">\n\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlInline\">Remember me</label>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class=\"d-flex justify-content-center mt-3 login_container\">\n\t\t\t\t \t<button type=\"button\" name=\"button\" class=\"btn login_btn\">Login</button>\n\t\t\t\t   </div>\n\t\t\t\t\t</form>\n\t\t\t\t</div>\n\t\t\n\t\t\t\t<div class=\"mt-4\">\n\t\t\t\t\t<div class=\"d-flex justify-content-center links\">\n\t\t\t\t\t\tDon't have an account? <a href=\"#\" class=\"ml-2\">Sign Up</a>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"d-flex justify-content-center links\">\n\t\t\t\t\t\t<a href=\"#\">Forgot your password?</a>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/find-page/find-page.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/find-page/find-page.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid baby_img pt-5\">\n    <div class=\"row pt-5\"></div>\n   <div class=\"row pt-5\">\n          <div class=\"col-2\"></div>\n         <div class=\"col-8 pt-5\">\n            <button type=\"button\" class=\"btn btn-success mt-5\" (click)=\"findExpert()\">FIND EXPERT</button>\n         </div>\n         <div class=\"col-2\"></div>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/functions-page/functions-page.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/functions-page/functions-page.component.html ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"row mt-5\">\n        <div class=\"col-12 text-center\">\n            <img style=\"width: 30px;\" src=\"assets/images/home.svg\" alt=\"\">\n        </div>\n    </div>\n    <div class=\"row mt-5\">\n        <div class=\"col-3\"></div>\n        <div class=\"col-6\">\n            <button type=\"button\" class=\"btn btn-dark\">Schedules</button>\n            <button type=\"button\" class=\"btn btn-dark\">Documents</button>\n            <button type=\"button\" class=\"btn btn-dark\">Support</button>\n        </div>\n        <div class=\"col-3\"></div>\n       \n    </div>\n    <div class=\"row mt-5\">\n        <div class=\"col-12\">\n            <img class=\"fun_img\" src=\"assets/images/left-white-arrow.svg\" alt=\"\">\n        </div>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/login/login.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/login/login.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"row pt-5\">\n        <div class=\"col-12 text-center pt-5\">\n            <img class=\"shield\" src=\"assets/images/shield.svg\" alt=\"\">\n        </div>\n    </div>\n    <div class=\"row pt-5\">\n        <div class=\"col-12 pt-5\">\n            <button type=\"button\" class=\"btn btn-success\" (click)=\"login()\">Login With Quickbooks</button>\n        </div>\n    </div>\n    <div class=\"row pt-3\">\n        <!-- <div class=\"col-12\">\n            <p routerLink=\"../find-page\">Find Page</p>\n            <p routerLink=\"../choose-page\">Choose Page</p>\n            <p routerLink=\"../selected-page\">Selected Page</p>\n            <p routerLink=\"../optioins-page\">Options Page</p>\n            <p routerLink=\"../function-page\">Funtions Page</p>\n\n        </div> -->\n    </div>\n    <div class=\"row pt-5\">\n        <div class=\"col-12 arrow\">\n            <img class=\"right-white-arrow\" (click)=\"choose()\" src=\"assets/images/right-white-arrow.svg\" alt=\"\">\n        </div>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/options-page/options-page.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/options-page/options-page.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"row mt-5\">\n        <div class=\"col-12\">\n           <h3> Welcome {{company}} </h3>\n        </div>\n        <br>\n        <!-- <div class=\"col-12 text-center\">\n            <img style=\"width: 30px;\" src=\"assets/images/flash.svg\" alt=\"\">\n        </div> -->\n    </div>\n    <div class=\"row mt-3\">\n        <div class=\"col-1\"></div>\n        <div class=\"col-3\">\n            <!-- <label class=\"switch\">\n                <input type=\"checkbox\">\n                <span class=\"slider round\"></span>\n            </label> -->\n        </div>\n        <div class=\"col-12\">\n            <h4 class=\" mt-1\"><img style=\"width: 30px;margin-right: 20px;\" src=\"assets/images/flash.svg\" alt=\"\"> Let's find your Expert!</h4>\n        </div>\n        <div class=\"col-1\"></div>\n    </div>\n    <div class=\"row mt-5\">\n        <div class=\"col-3\"></div>\n        <div class=\"col-6\">\n            <div class=\"form-check\">\n                <label class=\"form-check-label\">\n                    <input type=\"checkbox\" class=\"form-check-input\" value=\"Legal\"><span class=\"check_lable\">Legal</span>\n                </label>\n            </div>\n            <div class=\"form-check\">\n                <label class=\"form-check-label\">\n                    <input type=\"checkbox\" class=\"form-check-input\" value=\"Accountant\"><span\n                        class=\"check_lable\">Accountant</span>\n                </label>\n            </div>\n            <div class=\"form-check\">\n                <label class=\"form-check-label\">\n                    <input type=\"checkbox\" class=\"form-check-input\" value=\"Marketing\"><span\n                        class=\"check_lable\">Marketing</span>\n                </label>\n            </div>\n        </div>\n        <div class=\"col-3\"></div>\n    </div>\n        <div class=\"row mt-5\">\n            <div class=\"col-12\">\n<div class=\"custom-control custom-radio\">\n    <input type=\"radio\" class=\"custom-control-input\" id=\"ENGLISH\" name=\"defaultExampleRadios\">\n    <label class=\"custom-control-label\" for=\"ENGLISH\">ENGLISH</label>\n  </div>\n    <div class=\"custom-control custom-radio\">\n    <input type=\"radio\" class=\"custom-control-input\" id=\"HINDI\" name=\"defaultExampleRadios\">\n    <label class=\"custom-control-label\" for=\"HINDI\">HINDI</label>\n  </div>\n  <div class=\"custom-control custom-radio\">\n    <input type=\"radio\" class=\"custom-control-input\" id=\"ESPN\" name=\"defaultExampleRadios\">\n    <label class=\"custom-control-label\" for=\"ESPN\">ESPN</label>\n  </div>\n            </div>\n        </div>\n        <div class=\"row mt-5\">\n            <div class=\"col-12 text-right pt-5\">\n                <img style=\"width:30px\" (click)=\"choose()\" src=\"assets/images/right-white-arrow.svg\" alt=\"\">\n            </div>\n        </div>\n    </div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/selected-page/selected-page.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/selected-page/selected-page.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid p-0\">\n    <div class=\"row\" style=\"padding: 15px;\">\n        <div class=\"col-12\">\n            <!-- <section class=\"baby_img\">\n            </section> -->\n            <img class=\"baby_img\" src=\"assets/Profilepic/{{selected.name}}.jpg\" alt=\"\">\n        </div>\n        <br>\n        <div class=\"col-12\" style=\"text-align: center;\">\n            <!-- <div class=\"col-6\" style=\"text-align:left;\"> -->\n                <h3>{{selected.name}}</h3>\n            <!-- </div> -->\n            <!-- <div class=\"col-6\" style=\"text-align:right;\"> -->\n                <h4>{{selected['price/hr']}}</h4>\n            <!-- </div> -->\n            {{selected['experience']}}\n            <br>\n        </div>\n    </div>\n     <div class=\"row pt-4\">\n         <div class=\"col-2\"></div>\n         <div class=\"col-8 text-center\">\n            <h2>ACCOUNTANT</h2>\n            <img class=\"star\" src=\"assets/images/star-outline2.svg\" alt=\"\">\n            <img class=\"star\" src=\"assets/images/star-outline2.svg\" alt=\"\">\n            <img class=\"star\" src=\"assets/images/star-outline2.svg\" alt=\"\">\n            <img class=\"star\" src=\"assets/images/star-outline2.svg\" alt=\"\">\n            <img class=\"star\" src=\"assets/images/star-outline.svg\" alt=\"\">\n            <button type=\"button\" class=\"btn btn-success mt-3\" (click)=\"book()\">Book</button>\n         </div>\n         <div class=\"col-2\"></div>\n    </div>\n</div>"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _components_find_page_find_page_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/find-page/find-page.component */ "./src/app/components/find-page/find-page.component.ts");
/* harmony import */ var _components_choose_page_choose_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/choose-page/choose-page.component */ "./src/app/components/choose-page/choose-page.component.ts");
/* harmony import */ var _components_selected_page_selected_page_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/selected-page/selected-page.component */ "./src/app/components/selected-page/selected-page.component.ts");
/* harmony import */ var _components_options_page_options_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/options-page/options-page.component */ "./src/app/components/options-page/options-page.component.ts");
/* harmony import */ var _components_functions_page_functions_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/functions-page/functions-page.component */ "./src/app/components/functions-page/functions-page.component.ts");
/* harmony import */ var _components_calender_calender_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/calender/calender.component */ "./src/app/components/calender/calender.component.ts");










const routes = [
    { path: '', redirectTo: '/find-page', pathMatch: 'full' },
    { path: 'login', component: _components_login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"] },
    { path: 'find-page', component: _components_find_page_find_page_component__WEBPACK_IMPORTED_MODULE_4__["FindPageComponent"] },
    { path: 'choose-page', component: _components_choose_page_choose_page_component__WEBPACK_IMPORTED_MODULE_5__["ChoosePageComponent"] },
    { path: 'selected-page', component: _components_selected_page_selected_page_component__WEBPACK_IMPORTED_MODULE_6__["SelectedPageComponent"] },
    { path: 'optioins-page', component: _components_options_page_options_page_component__WEBPACK_IMPORTED_MODULE_7__["OptionsPageComponent"] },
    { path: 'function-page', component: _components_functions_page_functions_page_component__WEBPACK_IMPORTED_MODULE_8__["FunctionsPageComponent"] },
    { path: 'calender', component: _components_calender_calender_component__WEBPACK_IMPORTED_MODULE_9__["CalenderComponent"] },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { useHash: true })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AppComponent = class AppComponent {
    constructor() {
        this.title = 'marketapp';
    }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
        styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm2015/service-worker.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _components_components_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/components.component */ "./src/app/components/components.component.ts");
/* harmony import */ var ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ng-uikit-pro-standard */ "./node_modules/ng-uikit-pro-standard/fesm2015/ng-uikit-pro-standard.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm2015/animations.js");
/* harmony import */ var angular_image_slider__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! angular-image-slider */ "./node_modules/angular-image-slider/fesm2015/angular-image-slider.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm2015/http.js");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _components_find_page_find_page_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/find-page/find-page.component */ "./src/app/components/find-page/find-page.component.ts");
/* harmony import */ var _components_choose_page_choose_page_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/choose-page/choose-page.component */ "./src/app/components/choose-page/choose-page.component.ts");
/* harmony import */ var _components_selected_page_selected_page_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./components/selected-page/selected-page.component */ "./src/app/components/selected-page/selected-page.component.ts");
/* harmony import */ var _components_options_page_options_page_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./components/options-page/options-page.component */ "./src/app/components/options-page/options-page.component.ts");
/* harmony import */ var _components_functions_page_functions_page_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components/functions-page/functions-page.component */ "./src/app/components/functions-page/functions-page.component.ts");
/* harmony import */ var _components_calender_calender_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components/calender/calender.component */ "./src/app/components/calender/calender.component.ts");













// import {HttpClient} from '@angular/common/http'








let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
            _components_components_component__WEBPACK_IMPORTED_MODULE_8__["ComponentsComponent"],
            _components_login_login_component__WEBPACK_IMPORTED_MODULE_14__["LoginComponent"],
            _components_find_page_find_page_component__WEBPACK_IMPORTED_MODULE_15__["FindPageComponent"],
            _components_choose_page_choose_page_component__WEBPACK_IMPORTED_MODULE_16__["ChoosePageComponent"],
            _components_selected_page_selected_page_component__WEBPACK_IMPORTED_MODULE_17__["SelectedPageComponent"],
            _components_options_page_options_page_component__WEBPACK_IMPORTED_MODULE_18__["OptionsPageComponent"],
            _components_functions_page_functions_page_component__WEBPACK_IMPORTED_MODULE_19__["FunctionsPageComponent"],
            _components_calender_calender_component__WEBPACK_IMPORTED_MODULE_20__["CalenderComponent"],
        ],
        imports: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
            ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_9__["ToastModule"].forRoot(),
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__["BrowserAnimationsModule"],
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_6__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].production }),
            angular_image_slider__WEBPACK_IMPORTED_MODULE_11__["SliderModule"],
            _angular_http__WEBPACK_IMPORTED_MODULE_13__["HttpModule"]
        ],
        providers: [],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/components/calender/calender.component.css":
/*!************************************************************!*\
  !*** ./src/app/components/calender/calender.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvY2FsZW5kZXIvY2FsZW5kZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/components/calender/calender.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/calender/calender.component.ts ***!
  \***********************************************************/
/*! exports provided: CalenderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalenderComponent", function() { return CalenderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let CalenderComponent = class CalenderComponent {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    schedule() {
        this._router.navigateByUrl('/function-page');
    }
};
CalenderComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
CalenderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-calender',
        template: __webpack_require__(/*! raw-loader!./calender.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/calender/calender.component.html"),
        styles: [__webpack_require__(/*! ./calender.component.css */ "./src/app/components/calender/calender.component.css")]
    })
], CalenderComponent);



/***/ }),

/***/ "./src/app/components/choose-page/choose-page.component.css":
/*!******************************************************************!*\
  !*** ./src/app/components/choose-page/choose-page.component.css ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".baby_img{\n    /* background-image: url('/assets/images/men-photo.jpg'); */\n    width: 100%;\n    height: 40vh;\n    background-repeat: no-repeat;\n    border-radius: 8px;\n    background-size: cover;\n}\nimg.right-white{\n    width: 29px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9jaG9vc2UtcGFnZS9jaG9vc2UtcGFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksMkRBQTJEO0lBQzNELFdBQVc7SUFDWCxZQUFZO0lBQ1osNEJBQTRCO0lBQzVCLGtCQUFrQjtJQUNsQixzQkFBc0I7QUFDMUI7QUFDQTtJQUNJLFdBQVc7QUFDZiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvY2hvb3NlLXBhZ2UvY2hvb3NlLXBhZ2UuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iYWJ5X2ltZ3tcbiAgICAvKiBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1hZ2VzL21lbi1waG90by5qcGcnKTsgKi9cbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDQwdmg7XG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cbmltZy5yaWdodC13aGl0ZXtcbiAgICB3aWR0aDogMjlweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/choose-page/choose-page.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/choose-page/choose-page.component.ts ***!
  \*****************************************************************/
/*! exports provided: ChoosePageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChoosePageComponent", function() { return ChoosePageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let ChoosePageComponent = class ChoosePageComponent {
    constructor(_router) {
        this._router = _router;
        this.choices = [
            {
                "name": "Abhishek",
                "experience": "Senior",
                "price/hr": "1000 INR",
                "skill": "accounting",
                "language": ["english", "hindi", "Telugu"]
            },
            {
                "name": "Basvaraj",
                "experience": "Senior",
                "price/hr": "1500 INR",
                "skill": "accounting",
                "language": ["english", "hindi", "kanada"]
            },
            {
                "name": "Apoorva",
                "experience": "Junior",
                "price/hr": "700 INR",
                "skill": "accounting",
                "language": ["english", "hindi", "Espanol"]
            }
        ];
        this.selected = {};
        this.choice = 0;
    }
    ngOnInit() {
        this.selected = this.choices[0];
    }
    nextChoice() {
        this.choice++;
        if (this.choice >= this.choices.length) {
            this.choice = 0;
        }
        this.selected = this.choices[this.choice];
    }
    select() {
        localStorage.setItem("selected", JSON.stringify(this.selected));
        this._router.navigateByUrl('/selected-page');
        //optioins-page
    }
};
ChoosePageComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
ChoosePageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-choose-page',
        template: __webpack_require__(/*! raw-loader!./choose-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/choose-page/choose-page.component.html"),
        styles: [__webpack_require__(/*! ./choose-page.component.css */ "./src/app/components/choose-page/choose-page.component.css")]
    })
], ChoosePageComponent);



/***/ }),

/***/ "./src/app/components/components.component.css":
/*!*****************************************************!*\
  !*** ./src/app/components/components.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\t/* Coded with love by Mutiullah Samim */\n    body,\n    html {\n        margin: 0;\n        padding: 0;\n        height: 100%;\n        background: #60a3bc !important;\n    }\n    .user_card {\n        height: 400px;\n        width: 350px;\n        margin-top: auto;\n        margin-bottom: auto;\n        background: #f39c12;\n        position: relative;\n        top: 121px;\n        display: flex;\n        justify-content: center;\n        flex-direction: column;\n        padding: 10px;\n        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);\n        -webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);\n        -moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);\n        border-radius: 5px;\n\n    }\n    .brand_logo_container {\n        position: absolute;\n        height: 170px;\n        width: 170px;\n        top: -75px;\n        border-radius: 50%;\n        background: #60a3bc;\n        padding: 10px;\n        text-align: center;\n    }\n    .brand_logo {\n        height: 150px;\n        width: 150px;\n        border-radius: 50%;\n        border: 2px solid white;\n    }\n    .form_container {\n        margin-top: 100px;\n    }\n    .login_btn {\n        width: 100%;\n        background: #c0392b !important;\n        color: white !important;\n    }\n    .login_btn:focus {\n        box-shadow: none !important;\n        outline: 0px !important;\n    }\n    .login_container {\n        padding: 0 2rem;\n    }\n    .input-group-text {\n        background: #c0392b !important;\n        color: white !important;\n        border: 0 !important;\n        border-radius: 0.25rem 0 0 0.25rem !important;\n    }\n    .input_user,\n    .input_pass:focus {\n        box-shadow: none !important;\n        outline: 0px !important;\n    }\n    .custom-checkbox .custom-control-input:checked~.custom-control-label::before {\n        background-color: #c0392b !important;\n    }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9jb21wb25lbnRzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkNBQUMsdUNBQXVDO0lBQ3BDOztRQUVJLFNBQVM7UUFDVCxVQUFVO1FBQ1YsWUFBWTtRQUNaLDhCQUE4QjtJQUNsQztJQUNBO1FBQ0ksYUFBYTtRQUNiLFlBQVk7UUFDWixnQkFBZ0I7UUFDaEIsbUJBQW1CO1FBQ25CLG1CQUFtQjtRQUNuQixrQkFBa0I7UUFDbEIsVUFBVTtRQUNWLGFBQWE7UUFDYix1QkFBdUI7UUFDdkIsc0JBQXNCO1FBQ3RCLGFBQWE7UUFDYiw0RUFBNEU7UUFDNUUsb0ZBQW9GO1FBQ3BGLGlGQUFpRjtRQUNqRixrQkFBa0I7O0lBRXRCO0lBQ0E7UUFDSSxrQkFBa0I7UUFDbEIsYUFBYTtRQUNiLFlBQVk7UUFDWixVQUFVO1FBQ1Ysa0JBQWtCO1FBQ2xCLG1CQUFtQjtRQUNuQixhQUFhO1FBQ2Isa0JBQWtCO0lBQ3RCO0lBQ0E7UUFDSSxhQUFhO1FBQ2IsWUFBWTtRQUNaLGtCQUFrQjtRQUNsQix1QkFBdUI7SUFDM0I7SUFDQTtRQUNJLGlCQUFpQjtJQUNyQjtJQUNBO1FBQ0ksV0FBVztRQUNYLDhCQUE4QjtRQUM5Qix1QkFBdUI7SUFDM0I7SUFDQTtRQUNJLDJCQUEyQjtRQUMzQix1QkFBdUI7SUFDM0I7SUFDQTtRQUNJLGVBQWU7SUFDbkI7SUFDQTtRQUNJLDhCQUE4QjtRQUM5Qix1QkFBdUI7UUFDdkIsb0JBQW9CO1FBQ3BCLDZDQUE2QztJQUNqRDtJQUNBOztRQUVJLDJCQUEyQjtRQUMzQix1QkFBdUI7SUFDM0I7SUFDQTtRQUNJLG9DQUFvQztJQUN4QyIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvY29tcG9uZW50cy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHQvKiBDb2RlZCB3aXRoIGxvdmUgYnkgTXV0aXVsbGFoIFNhbWltICovXG4gICAgYm9keSxcbiAgICBodG1sIHtcbiAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIGJhY2tncm91bmQ6ICM2MGEzYmMgIWltcG9ydGFudDtcbiAgICB9XG4gICAgLnVzZXJfY2FyZCB7XG4gICAgICAgIGhlaWdodDogNDAwcHg7XG4gICAgICAgIHdpZHRoOiAzNTBweDtcbiAgICAgICAgbWFyZ2luLXRvcDogYXV0bztcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogYXV0bztcbiAgICAgICAgYmFja2dyb3VuZDogI2YzOWMxMjtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IDEyMXB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDZweCAyMHB4IDAgcmdiYSgwLCAwLCAwLCAwLjE5KTtcbiAgICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgNnB4IDIwcHggMCByZ2JhKDAsIDAsIDAsIDAuMTkpO1xuICAgICAgICAtbW96LWJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4yKSwgMCA2cHggMjBweCAwIHJnYmEoMCwgMCwgMCwgMC4xOSk7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcblxuICAgIH1cbiAgICAuYnJhbmRfbG9nb19jb250YWluZXIge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGhlaWdodDogMTcwcHg7XG4gICAgICAgIHdpZHRoOiAxNzBweDtcbiAgICAgICAgdG9wOiAtNzVweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICBiYWNrZ3JvdW5kOiAjNjBhM2JjO1xuICAgICAgICBwYWRkaW5nOiAxMHB4O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuICAgIC5icmFuZF9sb2dvIHtcbiAgICAgICAgaGVpZ2h0OiAxNTBweDtcbiAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xuICAgIH1cbiAgICAuZm9ybV9jb250YWluZXIge1xuICAgICAgICBtYXJnaW4tdG9wOiAxMDBweDtcbiAgICB9XG4gICAgLmxvZ2luX2J0biB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBiYWNrZ3JvdW5kOiAjYzAzOTJiICFpbXBvcnRhbnQ7XG4gICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAubG9naW5fYnRuOmZvY3VzIHtcbiAgICAgICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAgICAgICBvdXRsaW5lOiAwcHggIWltcG9ydGFudDtcbiAgICB9XG4gICAgLmxvZ2luX2NvbnRhaW5lciB7XG4gICAgICAgIHBhZGRpbmc6IDAgMnJlbTtcbiAgICB9XG4gICAgLmlucHV0LWdyb3VwLXRleHQge1xuICAgICAgICBiYWNrZ3JvdW5kOiAjYzAzOTJiICFpbXBvcnRhbnQ7XG4gICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgICBib3JkZXI6IDAgIWltcG9ydGFudDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMC4yNXJlbSAwIDAgMC4yNXJlbSAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAuaW5wdXRfdXNlcixcbiAgICAuaW5wdXRfcGFzczpmb2N1cyB7XG4gICAgICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgICAgICAgb3V0bGluZTogMHB4ICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIC5jdXN0b20tY2hlY2tib3ggLmN1c3RvbS1jb250cm9sLWlucHV0OmNoZWNrZWR+LmN1c3RvbS1jb250cm9sLWxhYmVsOjpiZWZvcmUge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzAzOTJiICFpbXBvcnRhbnQ7XG4gICAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/components/components.component.ts":
/*!****************************************************!*\
  !*** ./src/app/components/components.component.ts ***!
  \****************************************************/
/*! exports provided: ComponentsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentsComponent", function() { return ComponentsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ComponentsComponent = class ComponentsComponent {
    constructor() { }
    ngOnInit() {
    }
};
ComponentsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-components',
        template: __webpack_require__(/*! raw-loader!./components.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/components.component.html"),
        styles: [__webpack_require__(/*! ./components.component.css */ "./src/app/components/components.component.css")]
    })
], ComponentsComponent);



/***/ }),

/***/ "./src/app/components/find-page/find-page.component.css":
/*!**************************************************************!*\
  !*** ./src/app/components/find-page/find-page.component.css ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".baby_img{\n    background-image: url('/assets/images/back.jpg');\n    width: 100%;\n    height: 100vh;\n    background-repeat: no-repeat;\n    background-size: cover;\n    background-position-x: center;\n}\nbutton.btn.btn-success {\n    width: 100%;\n    padding: 16px 0px;\n    background-color: #05EFAA;\n    font-weight: 600;\n    font-size: 17px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9maW5kLXBhZ2UvZmluZC1wYWdlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxnREFBZ0Q7SUFDaEQsV0FBVztJQUNYLGFBQWE7SUFDYiw0QkFBNEI7SUFDNUIsc0JBQXNCO0lBQ3RCLDZCQUE2QjtBQUNqQztBQUNBO0lBQ0ksV0FBVztJQUNYLGlCQUFpQjtJQUNqQix5QkFBeUI7SUFDekIsZ0JBQWdCO0lBQ2hCLGVBQWU7QUFDbkIiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2ZpbmQtcGFnZS9maW5kLXBhZ2UuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iYWJ5X2ltZ3tcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1hZ2VzL2JhY2suanBnJyk7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDB2aDtcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbi14OiBjZW50ZXI7XG59XG5idXR0b24uYnRuLmJ0bi1zdWNjZXNzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAxNnB4IDBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDVFRkFBO1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgZm9udC1zaXplOiAxN3B4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/find-page/find-page.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/find-page/find-page.component.ts ***!
  \*************************************************************/
/*! exports provided: FindPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FindPageComponent", function() { return FindPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let FindPageComponent = class FindPageComponent {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    findExpert() {
        this._router.navigateByUrl('/login');
        //optioins-page
    }
};
FindPageComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
FindPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-find-page',
        template: __webpack_require__(/*! raw-loader!./find-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/find-page/find-page.component.html"),
        styles: [__webpack_require__(/*! ./find-page.component.css */ "./src/app/components/find-page/find-page.component.css")]
    })
], FindPageComponent);



/***/ }),

/***/ "./src/app/components/functions-page/functions-page.component.css":
/*!************************************************************************!*\
  !*** ./src/app/components/functions-page/functions-page.component.css ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "button.btn.btn-dark {\n    display: block;\n    margin-bottom: 52px;\n    width: 100%;\n}\n.fun_img{\n    width: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9mdW5jdGlvbnMtcGFnZS9mdW5jdGlvbnMtcGFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLG1CQUFtQjtJQUNuQixXQUFXO0FBQ2Y7QUFDQTtJQUNJLFdBQVc7QUFDZiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZnVuY3Rpb25zLXBhZ2UvZnVuY3Rpb25zLXBhZ2UuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbImJ1dHRvbi5idG4uYnRuLWRhcmsge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG1hcmdpbi1ib3R0b206IDUycHg7XG4gICAgd2lkdGg6IDEwMCU7XG59XG4uZnVuX2ltZ3tcbiAgICB3aWR0aDogMzBweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/functions-page/functions-page.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/components/functions-page/functions-page.component.ts ***!
  \***********************************************************************/
/*! exports provided: FunctionsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FunctionsPageComponent", function() { return FunctionsPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FunctionsPageComponent = class FunctionsPageComponent {
    constructor() { }
    ngOnInit() {
    }
};
FunctionsPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-functions-page',
        template: __webpack_require__(/*! raw-loader!./functions-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/functions-page/functions-page.component.html"),
        styles: [__webpack_require__(/*! ./functions-page.component.css */ "./src/app/components/functions-page/functions-page.component.css")]
    })
], FunctionsPageComponent);



/***/ }),

/***/ "./src/app/components/login/login.component.css":
/*!******************************************************!*\
  !*** ./src/app/components/login/login.component.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img.shield{\n    width: 36px;\n}\nbutton.btn.btn-success {\n    width: 100%;\n    padding: 16px 0px;\n    background-color: #17B53C;\n    font-size: 19px;\n}\nimg.right-white-arrow{\n    width: 36px;\n    float: right;\n}\n.arrow{\n    position: absolute;\n    bottom: 102px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9sb2dpbi9sb2dpbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksV0FBVztBQUNmO0FBQ0E7SUFDSSxXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLHlCQUF5QjtJQUN6QixlQUFlO0FBQ25CO0FBQ0E7SUFDSSxXQUFXO0lBQ1gsWUFBWTtBQUNoQjtBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLGFBQWE7QUFDakIiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpbWcuc2hpZWxke1xuICAgIHdpZHRoOiAzNnB4O1xufVxuYnV0dG9uLmJ0bi5idG4tc3VjY2VzcyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZzogMTZweCAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE3QjUzQztcbiAgICBmb250LXNpemU6IDE5cHg7XG59XG5pbWcucmlnaHQtd2hpdGUtYXJyb3d7XG4gICAgd2lkdGg6IDM2cHg7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuLmFycm93e1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDEwMnB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/login/login.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/components/login/login.component.ts ***!
  \*****************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");




let LoginComponent = class LoginComponent {
    constructor(_router, http) {
        this._router = _router;
        this.http = http;
    }
    ngOnInit() {
    }
    getCall() {
        // var url = "http://localhost:5000/getCall"
        var url = "https://qb-findy-app.herokuapp.com/getCall";
        return this.http.get(url);
    }
    login() {
        // this.getCall().subscribe((authUri)=>{
        //   // console.log(data)
        //   var url = authUri
        //   var parameters = "location=1,width=800,height=650";
        //             parameters += ",left=" + (screen.width - 800) / 2 + ",top=" + (screen.height - 650) / 2;
        //             var win = window.open(""+url, 'connectPopup', parameters);
        //             var pollOAuth = window.setInterval(function () {
        //                 try {
        //                     if (win.document.URL.indexOf("code") != -1) {
        //                         window.clearInterval(pollOAuth);
        //                         win.close();
        //                         location.reload();
        //                     }
        //                 } catch (e) {
        //                     console.log(e)
        //                 }
        //             }, 100);
        // })
        this.getCall().subscribe((data) => {
            // console.log(data)
            var json = JSON.parse(data);
            // console.log()
            if (json) {
                var company = json["CompanyInfo"]["CompanyName"];
                localStorage.setItem("company", company);
            }
            this._router.navigateByUrl('/optioins-page');
        });
        //optioins-page
    }
    choose() {
        this._router.navigateByUrl('/choose-page');
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: __webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/login/login.component.html"),
        styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/components/login/login.component.css")]
    })
], LoginComponent);



/***/ }),

/***/ "./src/app/components/options-page/options-page.component.css":
/*!********************************************************************!*\
  !*** ./src/app/components/options-page/options-page.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".switch {\n    position: relative;\n    display: inline-block;\n    width: 60px;\n    height: 34px;\n  }\n  \n  .switch input { \n    opacity: 0;\n    width: 0;\n    height: 0;\n  }\n  \n  .slider {\n    position: absolute;\n    cursor: pointer;\n    top: 0;\n    left: 0;\n    right: 0;\n    bottom: 0;\n    background-color: #ccc;\n    transition: .4s;\n  }\n  \n  .slider:before {\n    position: absolute;\n    content: \"\";\n    height: 26px;\n    width: 26px;\n    left: 4px;\n    bottom: 4px;\n    background-color: white;\n    transition: .4s;\n  }\n  \n  input:checked + .slider {\n    background-color: #2196F3;\n  }\n  \n  input:focus + .slider {\n    box-shadow: 0 0 1px #2196F3;\n  }\n  \n  input:checked + .slider:before {\n    -webkit-transform: translateX(26px);\n    transform: translateX(26px);\n  }\n  \n  /* Rounded sliders */\n  \n  .slider.round {\n    border-radius: 34px;\n  }\n  \n  .slider.round:before {\n    border-radius: 50%;\n  }\n  \n  .connect_head{\n    font-size: 16px;\n    background: green;\n    color: #fff;\n    padding: 2px;\n  }\n  \n  .form-check {\n    padding-bottom: 16px;\n    font-size: 20px;\n    font-weight: 600;\n    color: #fff;\n}\n  \n  input.form-check-input {\n    width: 19px;\n    height: 20px;\n}\n  \n  .check_lable{\n    padding-left: 12px;\n}\n  \n  .custom-control.custom-radio {\n    display: initial;\n    margin: 0px 0px 0px 10px;\n    padding-left: 36px;\n    font-size: 19px;\n    font-weight: 600;\n    color: #fff;\n}\n  \n  .custom-control-label::after {\n    position: absolute;\n    top: .25rem;\n    left: 0;\n    display: block;\n    width: 26px;\n    height: 18px;\n    content: \"\";\n    background-repeat: no-repeat;\n    background-position: center center;\n    background-size: 17px;\n}\n  \n  .custom-control-label::before {\n    position: absolute;\n    top: 0px;\n    left: 0;\n    display: block;\n    width: 27px;\n    height: 27px;\n    pointer-events: none;\n    content: \"\";\n    -webkit-user-select: none;\n    -moz-user-select: none;\n    -ms-user-select: none;\n    user-select: none;\n    background-color: #dee2e6;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9vcHRpb25zLXBhZ2Uvb3B0aW9ucy1wYWdlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxrQkFBa0I7SUFDbEIscUJBQXFCO0lBQ3JCLFdBQVc7SUFDWCxZQUFZO0VBQ2Q7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsUUFBUTtJQUNSLFNBQVM7RUFDWDs7RUFFQTtJQUNFLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2YsTUFBTTtJQUNOLE9BQU87SUFDUCxRQUFRO0lBQ1IsU0FBUztJQUNULHNCQUFzQjtJQUV0QixlQUFlO0VBQ2pCOztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCLFdBQVc7SUFDWCxZQUFZO0lBQ1osV0FBVztJQUNYLFNBQVM7SUFDVCxXQUFXO0lBQ1gsdUJBQXVCO0lBRXZCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSx5QkFBeUI7RUFDM0I7O0VBRUE7SUFDRSwyQkFBMkI7RUFDN0I7O0VBRUE7SUFDRSxtQ0FBbUM7SUFFbkMsMkJBQTJCO0VBQzdCOztFQUVBLG9CQUFvQjs7RUFDcEI7SUFDRSxtQkFBbUI7RUFDckI7O0VBRUE7SUFDRSxrQkFBa0I7RUFDcEI7O0VBQ0E7SUFDRSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLFdBQVc7SUFDWCxZQUFZO0VBQ2Q7O0VBQ0E7SUFDRSxvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixXQUFXO0FBQ2Y7O0VBQ0E7SUFDSSxXQUFXO0lBQ1gsWUFBWTtBQUNoQjs7RUFDQTtJQUNJLGtCQUFrQjtBQUN0Qjs7RUFDQTtJQUNJLGdCQUFnQjtJQUNoQix3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsV0FBVztBQUNmOztFQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLFdBQVc7SUFDWCxPQUFPO0lBQ1AsY0FBYztJQUNkLFdBQVc7SUFDWCxZQUFZO0lBQ1osV0FBVztJQUNYLDRCQUE0QjtJQUM1QixrQ0FBa0M7SUFDbEMscUJBQXFCO0FBQ3pCOztFQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLFFBQVE7SUFDUixPQUFPO0lBQ1AsY0FBYztJQUNkLFdBQVc7SUFDWCxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLFdBQVc7SUFDWCx5QkFBeUI7SUFDekIsc0JBQXNCO0lBQ3RCLHFCQUFxQjtJQUNyQixpQkFBaUI7SUFDakIseUJBQXlCO0FBQzdCIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9vcHRpb25zLXBhZ2Uvb3B0aW9ucy1wYWdlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3dpdGNoIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogMzRweDtcbiAgfVxuICBcbiAgLnN3aXRjaCBpbnB1dCB7IFxuICAgIG9wYWNpdHk6IDA7XG4gICAgd2lkdGg6IDA7XG4gICAgaGVpZ2h0OiAwO1xuICB9XG4gIFxuICAuc2xpZGVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIGJvdHRvbTogMDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjY2NjO1xuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogLjRzO1xuICAgIHRyYW5zaXRpb246IC40cztcbiAgfVxuICBcbiAgLnNsaWRlcjpiZWZvcmUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBjb250ZW50OiBcIlwiO1xuICAgIGhlaWdodDogMjZweDtcbiAgICB3aWR0aDogMjZweDtcbiAgICBsZWZ0OiA0cHg7XG4gICAgYm90dG9tOiA0cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiAuNHM7XG4gICAgdHJhbnNpdGlvbjogLjRzO1xuICB9XG4gIFxuICBpbnB1dDpjaGVja2VkICsgLnNsaWRlciB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzIxOTZGMztcbiAgfVxuICBcbiAgaW5wdXQ6Zm9jdXMgKyAuc2xpZGVyIHtcbiAgICBib3gtc2hhZG93OiAwIDAgMXB4ICMyMTk2RjM7XG4gIH1cbiAgXG4gIGlucHV0OmNoZWNrZWQgKyAuc2xpZGVyOmJlZm9yZSB7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMjZweCk7XG4gICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWCgyNnB4KTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMjZweCk7XG4gIH1cbiAgXG4gIC8qIFJvdW5kZWQgc2xpZGVycyAqL1xuICAuc2xpZGVyLnJvdW5kIHtcbiAgICBib3JkZXItcmFkaXVzOiAzNHB4O1xuICB9XG4gIFxuICAuc2xpZGVyLnJvdW5kOmJlZm9yZSB7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB9XG4gIC5jb25uZWN0X2hlYWR7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGJhY2tncm91bmQ6IGdyZWVuO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIHBhZGRpbmc6IDJweDtcbiAgfVxuICAuZm9ybS1jaGVjayB7XG4gICAgcGFkZGluZy1ib3R0b206IDE2cHg7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgY29sb3I6ICNmZmY7XG59XG5pbnB1dC5mb3JtLWNoZWNrLWlucHV0IHtcbiAgICB3aWR0aDogMTlweDtcbiAgICBoZWlnaHQ6IDIwcHg7XG59XG4uY2hlY2tfbGFibGV7XG4gICAgcGFkZGluZy1sZWZ0OiAxMnB4O1xufVxuLmN1c3RvbS1jb250cm9sLmN1c3RvbS1yYWRpbyB7XG4gICAgZGlzcGxheTogaW5pdGlhbDtcbiAgICBtYXJnaW46IDBweCAwcHggMHB4IDEwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAzNnB4O1xuICAgIGZvbnQtc2l6ZTogMTlweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiAjZmZmO1xufVxuLmN1c3RvbS1jb250cm9sLWxhYmVsOjphZnRlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogLjI1cmVtO1xuICAgIGxlZnQ6IDA7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgd2lkdGg6IDI2cHg7XG4gICAgaGVpZ2h0OiAxOHB4O1xuICAgIGNvbnRlbnQ6IFwiXCI7XG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICAgIGJhY2tncm91bmQtc2l6ZTogMTdweDtcbn1cbi5jdXN0b20tY29udHJvbC1sYWJlbDo6YmVmb3JlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwcHg7XG4gICAgbGVmdDogMDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB3aWR0aDogMjdweDtcbiAgICBoZWlnaHQ6IDI3cHg7XG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgY29udGVudDogXCJcIjtcbiAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xuICAgIC1tb3otdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgLW1zLXVzZXItc2VsZWN0OiBub25lO1xuICAgIHVzZXItc2VsZWN0OiBub25lO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZWUyZTY7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/options-page/options-page.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/options-page/options-page.component.ts ***!
  \*******************************************************************/
/*! exports provided: OptionsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OptionsPageComponent", function() { return OptionsPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let OptionsPageComponent = class OptionsPageComponent {
    constructor(_router) {
        this._router = _router;
        this.company = "";
    }
    ngOnInit() {
        this.company = localStorage.getItem("company");
    }
    choose() {
        this._router.navigateByUrl('/choose-page');
    }
};
OptionsPageComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
OptionsPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-options-page',
        template: __webpack_require__(/*! raw-loader!./options-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/options-page/options-page.component.html"),
        styles: [__webpack_require__(/*! ./options-page.component.css */ "./src/app/components/options-page/options-page.component.css")]
    })
], OptionsPageComponent);



/***/ }),

/***/ "./src/app/components/selected-page/selected-page.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/components/selected-page/selected-page.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".baby_img{\n    background-image: url('/assets/images/men-photo.jpg');\n    width: 100%;\n    height: 40vh;\n    background-repeat: no-repeat;\n    background-size: cover;\n}\nbutton.btn.btn-success {\n    width: 100%;\n    padding: 16px 0px;\n    background-color: #009AFE;\n    font-weight: 600;\n    font-size: 17px;\n    border: none;\n}\nimg.star{\n    width: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9zZWxlY3RlZC1wYWdlL3NlbGVjdGVkLXBhZ2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHFEQUFxRDtJQUNyRCxXQUFXO0lBQ1gsWUFBWTtJQUNaLDRCQUE0QjtJQUM1QixzQkFBc0I7QUFDMUI7QUFDQTtJQUNJLFdBQVc7SUFDWCxpQkFBaUI7SUFDakIseUJBQXlCO0lBQ3pCLGdCQUFnQjtJQUNoQixlQUFlO0lBQ2YsWUFBWTtBQUNoQjtBQUNBO0lBQ0ksV0FBVztBQUNmIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9zZWxlY3RlZC1wYWdlL3NlbGVjdGVkLXBhZ2UuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iYWJ5X2ltZ3tcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1hZ2VzL21lbi1waG90by5qcGcnKTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDQwdmg7XG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuYnV0dG9uLmJ0bi5idG4tc3VjY2VzcyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZzogMTZweCAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwOUFGRTtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICBib3JkZXI6IG5vbmU7XG59XG5pbWcuc3RhcntcbiAgICB3aWR0aDogMzBweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/selected-page/selected-page.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/selected-page/selected-page.component.ts ***!
  \*********************************************************************/
/*! exports provided: SelectedPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectedPageComponent", function() { return SelectedPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let SelectedPageComponent = class SelectedPageComponent {
    constructor(_router) {
        this._router = _router;
        this.selected = {};
    }
    ngOnInit() {
        this.selected = JSON.parse(localStorage.getItem("selected"));
    }
    book() {
        //calender
        this._router.navigateByUrl('/calender');
    }
};
SelectedPageComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
SelectedPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-selected-page',
        template: __webpack_require__(/*! raw-loader!./selected-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/selected-page/selected-page.component.html"),
        styles: [__webpack_require__(/*! ./selected-page.component.css */ "./src/app/components/selected-page/selected-page.component.css")]
    })
], SelectedPageComponent);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/praveenax/Documents/KyraxCompany/MartApp/FIND/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map