var express = require("express");
var session = require('express-session');
var app = express();
var http = require('http').createServer(app);
const bodyParser = require('body-parser');

const OAuthClient = require('intuit-oauth');

const QBORequests = require('./QBORequests');
const OAuth2Helper = require('./OAuth2Helper');
const config = require('./config');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


const urlencodedParser = bodyParser.urlencoded({ extended: false });
let oauthClient = null;
let oauth2_token_json = null;
let redirectUri = '';

app.use(session({
    resave: false,
    saveUninitialized: true,
    secret: 'secret',
}))

app.use(function (req, res, next) {
    if (!req.session.accessToken) {
        req.session.accessToken = config.AccessToken
    }
    if (!req.session.refreshToken) {
        req.session.refreshToken = config.RefreshToken
    }
    if (!req.session.realmId) {
        req.session.realmId = config.RealmId
    }
    next()
})

//app.use('/', proxy());
// app.use(express.static('client'));
app.use(express.static('public'));
// app.use(express.static('carto-ui'));


app.get("/", function (req, res) {
    // res.sendfile('public/index.html');
    // res.sendfile('carto-ui/game.html');
    res.redirect('index.html');
});

function getUrl(){
    oauthClient = new OAuthClient({
        clientId: config.ClientId,
        clientSecret: config.ClientSecret,
        environment: config.environment,
        redirectUri: 'https://developer.intuit.com/v2/OAuth2Playground/RedirectUrl',
    });

    // console.log(oauthClient)

    const authUri = oauthClient.authorizeUri({
        scope: [OAuthClient.scopes.Accounting],
        state: 'intuit-test',
    });
    return authUri
}

app.get('/authUri', urlencodedParser, function (req, res) {
    oauthClient = new OAuthClient({
        clientId: config.ClientId,
        clientSecret: config.ClientSecret,
        environment: config.environment,
        redirectUri: 'http://localhost:5000/callback',
    });

    // console.log(oauthClient)

    const authUri = oauthClient.authorizeUri({
        scope: [OAuthClient.scopes.Accounting],
        state: 'intuit-test',
    });

    // res.redirect(authUri);

    // console.log(oauthClient.getToken().getToken())
    // res.send(authUri);
    res.json(authUri)
});



app.get('/callback', function (req, res) {

    console.log("callback called")
    // var authUrl = getUrl()
    oauthClient
        .createToken(req.url)
        .then(function (authResponse) {
            oauth2_token_json = JSON.stringify(authResponse.getJson(), null, 2);
            // console.log("PRAX")
            // console.log(oauth2_token_json)
        })
        .catch(function (e) {
            console.error(e);
        });

    res.send('');
});


app.get('/retrieveToken', function (req, res) {
    res.send(oauth2_token_json);
});


app.get('/refreshAccessToken', function (req, res) {
    oauthClient
        .refresh()
        .then(function (authResponse) {
            // console.log(`The Refresh Token is  ${JSON.stringify(authResponse.getJson())}`);
            oauth2_token_json = JSON.stringify(authResponse.getJson(), null, 2);
            res.send(oauth2_token_json);
        })
        .catch(function (e) {
            console.error(e);
        });
});

app.get('/disconnect', function (req, res) {
    console.log('The disconnect called ');
    const authUri = oauthClient.authorizeUri({
        scope: [OAuthClient.scopes.OpenId, OAuthClient.scopes.Email],
        state: 'intuit-test',
    });
    res.redirect(authUri);
});




app.get('/getCall', function (req, resp) {

    //get accessToken

    QBORequests.getCompanyInfo(config.AccessToken, config.RealmId, function (apiResponse) {
        // QBORequests.getCompanyInfo("AB116160811642upsCROnCUAHhwyCsMft5hnDLlNC8SEYDLkHS", "4620816365149626560", function (apiResponse) {
        if (JSON.parse(apiResponse.statusCode) === 401) {
            // OAuth2Helper.refreshAccessToken(req.session.refreshToken, function (tokenResp) {
                OAuth2Helper.refreshAccessToken(config.RefreshToken, function (tokenResp) {
                if (tokenResp != null) {
                    req.session.refreshToken = tokenResp.refresh_token;
                    req.session.accessToken = tokenResp.access_token;
                    QBORequests.getCompanyInfo(req.session.accessToken, req.session.realmId, function (apiResponseRetry) {
                        // console.log('After 401: ' + JSON.stringify(apiResponseRetry.body));
                        resp.send(JSON.stringify(apiResponseRetry.body));
                    });
                }
                else {
                    console.log('Refreshing access token failure.');
                }
            });
        }
        else if (JSON.parse(apiResponse.statusCode) === 200) {
            // console.log('Successful response ' + JSON.stringify(apiResponse.body));
            // resp.send(JSON.stringify(apiResponse.body));
            resp.json(apiResponse.body)
        }
        else {
            // console.log('Something went wrong. Here\'s the full response: ' + JSON.stringify(apiResponse));
            resp.send(JSON.stringify(apiResponse.body));
        }

    });
})

app.get('/postCall', function (req, resp) {
    QBORequests.createCustomer(req.session.accessToken, req.session.realmId, function (apiResponse) {
        if (JSON.parse(apiResponse.statusCode) === 401) {
            OAuth2Helper.refreshAccessToken(req.session.refreshToken, function (tokenResp) {
                if (tokenResp != null) {
                    req.session.refreshToken = tokenResp.refresh_token;
                    req.session.accessToken = tokenResp.access_token;
                    QBORequests.createCustomer(req.session.accessToken, req.session.realmId, function (apiResponseRetry) {
                        // console.log('After 401: ' + JSON.stringify(apiResponseRetry.body));
                        resp.send(JSON.stringify(apiResponseRetry.body));
                    });
                }
                else {
                    console.log('Refreshing access token failure.');
                }
            });
        }
        else if (JSON.parse(apiResponse.statusCode) === 200) {
            // console.log('Successful response ' + JSON.stringify(apiResponse.body));
            resp.send(JSON.stringify(apiResponse.body));
        }
        else {
            // console.log('Something went wrong. Here\'s the full response: ' + JSON.stringify(apiResponse));
            resp.send(JSON.stringify(apiResponse.body));
        }

    });
})

const PORT = process.env.PORT || 5000;
http.listen(PORT, function () {
    console.log("info", 'Listening on port ' + PORT); //Listening on port 8888
});

